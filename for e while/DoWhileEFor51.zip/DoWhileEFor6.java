public class DoWhileEFor6 {
    public static void main(String[] args) {
        int soma = 0;
        for (int i = 2; i <= 100; i += 2) {
            soma += i;
        }
        System.out.println("Soma dos pares de 1 a 100: " + soma);
    }
}


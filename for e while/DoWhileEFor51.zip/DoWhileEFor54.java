public class DoWhileEFor54 {
    public static void main(String[] args) {

        int num = 25;
        do {
            System.out.println("Raiz de " + num + " = " + Math.sqrt(num));
            num -= 5;
        } while (num >= 0);
    }
}


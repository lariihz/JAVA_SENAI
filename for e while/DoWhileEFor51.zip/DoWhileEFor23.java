public class DoWhileEFor23 {
    public static void main(String[] args) {
        
        for (int i = 0; i < 201; i++){
            if(i % 4 == 0){
                System.out.print(i + " ");
            }
        }
    }
}

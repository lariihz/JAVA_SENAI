public class DoWhileEFor24 {
    public static void main(String[] args) {

        for (int i = 1, t = 0; i <= 10; i++) { //dentro do for está a formula para se exibir do primeiro ate o decimo termo triangular.
            t += i;
            System.out.print(t + " ");
        }
    }
}

public class DoWhileEFor20 {
    public static void main(String[] args) {

        for (int i = 0; i <= 50; i += 5) {
            System.out.print(i + " ");
        }
    }
}

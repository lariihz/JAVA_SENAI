public class DoWhileEFor33 {
    public static void main(String[] args) {
        
        int number = 1;
        do {
            System.out.println(number);
            number ++;
        } while (number < 11);
    }
}

public class DoWhileEFor34 {
    public static void main(String[] args) {

        int i = 10;
        do {
            System.out.print(i-- + " ");
        } while (i >= 1);
    }
}

public class DoWhileEFor36 {
    public static void main(String[] args) {

        int soma = 0, i = 1;
        do {
            soma += i++;
        } while (i <= 50);
        System.out.println("Soma: " + soma);
    }
}

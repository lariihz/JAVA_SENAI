public class DoWhileEFor5 {
    public static void main(String[] args) {
        int soma = 0;
  
        for(int i = 0; i < 101; ++i) {
           soma += i;
        }
  
        System.out.println(soma);
     }
}

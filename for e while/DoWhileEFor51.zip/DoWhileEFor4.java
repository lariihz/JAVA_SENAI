public class DoWhileEFor4 {

    public static void main(String[] args) {
        for (int i = 1; i <= 19; i += 2) {
            System.out.print(i + " ");
        }
    }
}
